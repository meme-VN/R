
function startGame() {
  window.location.href = "levels/level1.html";
}
function openStore() {
  alert("Cửa hàng đang được cập nhật...");
}
function showAchievements() {
  alert("Chức năng thành tích đang phát triển...");
}
